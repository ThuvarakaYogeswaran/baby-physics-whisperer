import numpy as np
import matplotlib.pyplot as plt

class SmokeSimulator2D:
    """
    Simulates smoke concentration moving in a 2D grid with wind.
    This is our "ground truth" physics engine.
    """
    def __init__(self, width=64, height=64, wind_x=0.1, wind_y=0.05, diffusion=0.1):
        self.width = width
        self.height = height
        self.wind_x = wind_x
        self.wind_y = wind_y
        self.diffusion = diffusion
        
        self.smoke = np.zeros((height, width))
        
        # Create obstacle (wall)
        self.wall = np.zeros((height, width))
        self.wall[20:30, 40:50] = 1
        
    def add_smoke_source(self, x, y, amount=1.0):
        """Add smoke at a specific position"""
        if 0 <= x < self.width and 0 <= y < self.height:
            self.smoke[y, x] += amount
            
    def step(self):
        """Advance simulation by one time step"""
        new_smoke = self.smoke.copy()
        
        # Diffusion (spreading)
        for i in range(1, self.height-1):
            for j in range(1, self.width-1):
                if self.wall[i, j] == 0:
                    laplacian = (self.smoke[i+1, j] + self.smoke[i-1, j] +
                                self.smoke[i, j+1] + self.smoke[i, j-1] -
                                4 * self.smoke[i, j])
                    new_smoke[i, j] += self.diffusion * laplacian
        
        # Advection (wind movement)
        shifted = np.roll(self.smoke, int(self.wind_x*10), axis=1)
        shifted = np.roll(shifted, int(self.wind_y*10), axis=0)
        new_smoke = 0.7 * new_smoke + 0.3 * shifted
        
        # Walls block smoke
        new_smoke[self.wall == 1] = 0
        
        # Dissipation
        new_smoke *= 0.99
        
        self.smoke = np.maximum(new_smoke, 0)
        return self.smoke
    
    def reset(self):
        """Reset simulation to empty state"""
        self.smoke = np.zeros((self.height, self.width))
        
    def visualize(self, step=0):
        """Visualize current smoke concentration"""
        plt.clf()
        plt.imshow(self.smoke, cmap='hot', interpolation='bilinear')
        plt.colorbar(label='Smoke Concentration')
        plt.title(f'Time Step: {step}')
        plt.xlabel('X Position')
        plt.ylabel('Y Position')
        
        wall_y, wall_x = np.where(self.wall == 1)
        plt.scatter(wall_x, wall_y, c='blue', s=1, alpha=0.5, label='Wall')
        plt.legend()
        return plt.gcf()


if __name__ == "__main__":
    # Test the simulator
    sim = SmokeSimulator2D(width=64, height=64)
    sim.add_smoke_source(32, 32, amount=5.0)
    
    fig, ax = plt.subplots()
    def update(frame):
        sim.step()
        sim.visualize(frame)
    
    from matplotlib.animation import FuncAnimation
    ani = FuncAnimation(fig, update, frames=50, interval=50)
    plt.show()