import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.simulator import SmokeSimulator2D
import numpy as np

def test_simulator_initialization():
    sim = SmokeSimulator2D(width=32, height=32)
    assert sim.smoke.shape == (32, 32)
    assert np.sum(sim.smoke) == 0
    print("✓ test_simulator_initialization passed")

def test_add_smoke_source():
    sim = SmokeSimulator2D()
    sim.add_smoke_source(10, 10, amount=2.0)
    assert sim.smoke[10, 10] == 2.0
    print("✓ test_add_smoke_source passed")

def test_simulator_step():
    sim = SmokeSimulator2D()
    sim.add_smoke_source(32, 32, amount=5.0)
    initial_total = np.sum(sim.smoke)
    sim.step()
    after_total = np.sum(sim.smoke)
    assert after_total < initial_total
    print("✓ test_simulator_step passed")

def test_wall_blocks_smoke():
    sim = SmokeSimulator2D()
    sim.wall[20, 40] = 1
    sim.add_smoke_source(40, 20, amount=5.0)
    wall_position = sim.smoke[20, 40]
    assert wall_position == 0
    print("✓ test_wall_blocks_smoke passed")

def test_reset():
    sim = SmokeSimulator2D()
    sim.add_smoke_source(10, 10, amount=5.0)
    sim.reset()
    assert np.sum(sim.smoke) == 0
    print("✓ test_reset passed")

if __name__ == "__main__":
    test_simulator_initialization()
    test_add_smoke_source()
    test_simulator_step()
    test_wall_blocks_smoke()
    test_reset()
    print("\n✅ All simulator tests passed!")