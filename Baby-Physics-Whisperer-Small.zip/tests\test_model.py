import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
from src.model import PhysicsLearner
import numpy as np

def test_model_initialization():
    model = PhysicsLearner(input_channels=1, hidden_dim=32)
    assert isinstance(model, torch.nn.Module)
    print("✓ test_model_initialization passed")

def test_model_forward_shape():
    model = PhysicsLearner(input_channels=1)
    batch_size = 2
    height, width = 64, 64
    x = torch.randn(batch_size, 1, height, width)
    output = model(x)
    assert output.shape == (batch_size, 1, height, width)
    print("✓ test_model_forward_shape passed")

def test_model_predict_next():
    model = PhysicsLearner(input_channels=1)
    state = np.random.rand(64, 64)
    prediction = model.predict_next(state)
    assert prediction.shape == (64, 64)
    print("✓ test_model_predict_next passed")

def test_model_residual():
    model = PhysicsLearner(input_channels=1)
    x = torch.ones(1, 1, 10, 10)
    output = model(x)
    # Output should be close to input (initialized near zero)
    assert torch.allclose(output, x, atol=1.0)
    print("✓ test_model_residual passed")

if __name__ == "__main__":
    test_model_initialization()
    test_model_forward_shape()
    test_model_predict_next()
    test_model_residual()
    print("\n✅ All model tests passed!")