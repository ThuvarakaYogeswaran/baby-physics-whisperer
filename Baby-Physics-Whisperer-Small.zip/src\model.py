import torch
import torch.nn as nn

class PhysicsLearner(nn.Module):
    """
    Neural network that learns to predict next frame given current frame.
    Uses residual connections to predict changes rather than absolute values.
    """
    def __init__(self, input_channels=1, hidden_dim=32):
        super().__init__()
        
        # Encoder: compress to features
        self.encoder = nn.Sequential(
            nn.Conv2d(input_channels, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, hidden_dim, kernel_size=3, padding=1),
            nn.ReLU(),
        )
        
        # Processor: predict changes
        self.processor = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.ReLU(),
        )
        
        # Decoder: back to smoke concentration
        self.decoder = nn.Sequential(
            nn.Conv2d(hidden_dim, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, input_channels, kernel_size=3, padding=1),
        )
        
    def forward(self, x):
        # x shape: (batch, channels, height, width)
        latent = self.encoder(x)
        processed = self.processor(latent)
        change = self.decoder(processed)
        
        # Residual connection: predict the CHANGE
        return x + change
    
    def predict_next(self, current_state):
        """Convenience method for single predictions"""
        with torch.no_grad():
            if len(current_state.shape) == 2:
                current_state = current_state.reshape(1, 1, current_state.shape[0], current_state.shape[1])
            elif len(current_state.shape) == 3:
                current_state = current_state.unsqueeze(0)
            
            if not isinstance(current_state, torch.Tensor):
                current_state = torch.FloatTensor(current_state)
                
            next_tensor = self.forward(current_state)
            return next_tensor.squeeze().cpu().numpy()