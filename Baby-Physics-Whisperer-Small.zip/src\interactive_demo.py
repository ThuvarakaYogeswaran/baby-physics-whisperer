import torch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider
from matplotlib.animation import FuncAnimation
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.simulator import SmokeSimulator2D
from src.model import PhysicsLearner

# Load trained model
print("Loading trained model...")
model = PhysicsLearner(input_channels=1)
try:
    checkpoint = torch.load('models/best_model.pth', map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    print("✅ Model loaded successfully")
except:
    print("⚠️ No trained model found. Using untrained model.")
    print("   Run 'python src/train_online.py' first for better results.")

model.eval()

# Setup interactive simulation
sim = SmokeSimulator2D(width=64, height=64, wind_x=0.1, wind_y=0.05)
sim.add_smoke_source(32, 32, amount=3.0)

# Create figure
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
plt.subplots_adjust(bottom=0.25)

# Visualization
actual_img = ax1.imshow(sim.smoke, cmap='hot', vmin=0, vmax=2)
ax1.set_title('Actual Physics (Ground Truth)', fontsize=12)
ax1.set_xlabel('X Position')
ax1.set_ylabel('Y Position')
plt.colorbar(actual_img, ax=ax1)

pred_img = ax2.imshow(sim.smoke, cmap='hot', vmin=0, vmax=2)
ax2.set_title('AI Prediction', fontsize=12)
ax2.set_xlabel('X Position')
ax2.set_ylabel('Y Position')
plt.colorbar(pred_img, ax=ax2)

# Slider for wind speed
ax_wind = plt.axes([0.2, 0.12, 0.6, 0.03])
wind_slider = Slider(ax_wind, 'Wind Speed (X direction)', -0.3, 0.3, valinit=0.1)

# Slider for wind Y
ax_wind_y = plt.axes([0.2, 0.07, 0.6, 0.03])
wind_y_slider = Slider(ax_wind_y, 'Wind Speed (Y direction)', -0.3, 0.3, valinit=0.05)

# Button to add smoke
ax_button = plt.axes([0.4, 0.02, 0.2, 0.04])
smoke_button = Button(ax_button, '💨 Add Smoke Puff', color='lightblue', hovercolor='lightgreen')

# Button to reset
ax_reset = plt.axes([0.7, 0.02, 0.2, 0.04])
reset_button = Button(ax_reset, '🔄 Reset', color='lightcoral', hovercolor='orange')

# Status text
fig.text(0.02, 0.95, 'Click anywhere to add smoke | Use sliders to change wind', 
         fontsize=10, style='italic')

def update(frame):
    # Update simulator wind from sliders
    sim.wind_x = wind_slider.val
    sim.wind_y = wind_y_slider.val
    
    # Step physics
    sim.step()
    
    # Update actual visualization
    actual_img.set_array(sim.smoke)
    
    # Get AI prediction
    with torch.no_grad():
        state_tensor = torch.FloatTensor(sim.smoke).unsqueeze(0).unsqueeze(0)
        pred = model(state_tensor).squeeze().numpy()
        pred_img.set_array(pred)
    
    return [actual_img, pred_img]

def on_click(event):
    """Add smoke at click position"""
    if event.inaxes == ax1 or event.inaxes == ax2:
        x = int(event.xdata)
        y = int(event.ydata)
        if 0 <= x < 64 and 0 <= y < 64:
            sim.add_smoke_source(x, y, amount=2.0)
            print(f"💨 Added smoke at ({x}, {y})")

def add_smoke_event(event):
    """Button callback to add smoke at center"""
    sim.add_smoke_source(32, 32, amount=3.0)
    print("💨 Added smoke puff at center")

def reset_event(event):
    """Reset simulation"""
    sim.reset()
    sim.add_smoke_source(32, 32, amount=3.0)
    print("🔄 Simulation reset")

# Connect events
smoke_button.on_clicked(add_smoke_event)
reset_button.on_clicked(reset_event)
fig.canvas.mpl_connect('button_press_event', on_click)

# Run animation
ani = FuncAnimation(fig, update, interval=50, cache_frame_data=False)

print("\n" + "="*50)
print("INTERACTIVE DEMO CONTROLS")
print("="*50)
print("🎮 Controls:")
print("  - Click anywhere → Add smoke puff")
print("  - Adjust Wind X slider → Change horizontal wind")
print("  - Adjust Wind Y slider → Change vertical wind")
print("  - Add Smoke Puff button → Add smoke at center")
print("  - Reset button → Clear and restart")
print("\nClose the window to exit")
print("="*50)

plt.show()