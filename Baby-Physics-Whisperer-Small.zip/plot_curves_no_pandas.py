﻿import matplotlib.pyplot as plt
import numpy as np
import os
import csv

os.makedirs('outputs/figures', exist_ok=True)

# Load training data without pandas
loss = []
csv_path = 'outputs/logs/metrics.csv'

if os.path.exists(csv_path):
    with open(csv_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if len(row) > 1:
                try:
                    loss.append(float(row[1]))  # loss is second column
                except:
                    pass
    print(f"✅ Loaded {len(loss)} training steps")
else:
    print("⚠️ No metrics.csv found, using demo data")
    steps = 500
    for i in range(steps):
        if i < 150:
            l = 0.12 * np.exp(-i/50) + 0.02
        elif i < 250:
            l = 0.02 + 0.08 * np.exp(-(i-150)/20)
        else:
            l = 0.02 + 0.01 * np.sin(i/50)
        loss.append(l)

# Create plot
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Learning curve
axes[0].plot(loss, 'b-', linewidth=2, label='Prediction Error')
axes[0].axvline(x=min(250, len(loss)-1), color='r', linestyle='--', linewidth=2, label='Wind Changed')
axes[0].fill_between(range(len(loss)), loss, alpha=0.2)
axes[0].set_xlabel('Training Steps', fontsize=12)
axes[0].set_ylabel('Mean Squared Error (MSE)', fontsize=12)
axes[0].set_title('AI Learning Curve\nLower = Better Predictions', fontsize=14)
axes[0].legend(fontsize=10)
axes[0].grid(True, alpha=0.3)

# Add annotations if enough data
if len(loss) > 250:
    axes[0].annotate('Initial\nRandom Guesses', xy=(10, loss[10] if loss[10] > 0 else 0.11), 
                     xytext=(50, 0.13), arrowprops=dict(arrowstyle='->', color='gray'))
    axes[0].annotate('AI Masters\nPhysics', xy=(200, loss[200] if loss[200] > 0 else 0.025), 
                     xytext=(220, 0.05), arrowprops=dict(arrowstyle='->', color='green'))
    axes[0].annotate('Adapts to\nNew Wind', xy=(350, loss[350] if loss[350] > 0 else 0.035), 
                     xytext=(370, 0.06), arrowprops=dict(arrowstyle='->', color='orange'))

# Improvement bar chart
before = np.mean(loss[:50]) if len(loss) >= 50 else np.mean(loss[:len(loss)//2])
after = np.mean(loss[-50:]) if len(loss) >= 50 else np.mean(loss[len(loss)//2:])
improvement = (before - after) / before * 100 if before > 0 else 0

bars = axes[1].bar(['Before\nTraining', 'After\nTraining'], [before, after], 
                   color=['red', 'green'], alpha=0.7, edgecolor='black')
axes[1].set_ylabel('Prediction Error (MSE)', fontsize=12)
axes[1].set_title(f'{improvement:.0f}% Improvement!', fontsize=14)

# Add value labels
for bar, val in zip(bars, [before, after]):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.005,
                f'{val:.4f}', ha='center', va='bottom', fontsize=11, fontweight='bold')

axes[1].grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('outputs/figures/professional_curves.png', dpi=150, bbox_inches='tight')
print(f"\n✅ Saved to outputs/figures/professional_curves.png")
print(f"📊 Improvement: {improvement:.1f}%")
print(f"📈 Before training error: {before:.4f}")
print(f"📉 After training error: {after:.4f}")
print("\n🎯 Opening plot window...")
plt.show()
