"""
Baby Physics Whisperer - Standalone Demo
No external dependencies needed (only Python standard library + matplotlib)
"""

import sys
import os

# Check if matplotlib is available
try:
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
    import numpy as np
except ImportError:
    print("ERROR: matplotlib and numpy are required")
    print("Run: pip install matplotlib numpy")
    sys.exit(1)

print("="*50)
print("Baby Physics Whisperer - Interactive Demo")
print("="*50)

# Simple smoke simulator
class SmokeSimulator:
    def __init__(self, width=64, height=64):
        self.width = width
        self.height = height
        self.wind_x = 0.15
        self.wind_y = 0.05
        self.smoke = np.zeros((height, width))
        
        # Add a wall
        self.wall = np.zeros((height, width))
        self.wall[20:30, 40:50] = 1
        
        # Add initial smoke
        self.add_smoke(32, 32, 3.0)
        
    def add_smoke(self, x, y, amount):
        if 0 <= x < self.width and 0 <= y < self.height:
            self.smoke[y, x] += amount
            
    def step(self):
        new_smoke = self.smoke.copy()
        
        # Spread smoke
        for i in range(1, self.height-1):
            for j in range(1, self.width-1):
                if self.wall[i, j] == 0:
                    laplacian = (self.smoke[i+1, j] + self.smoke[i-1, j] +
                                self.smoke[i, j+1] + self.smoke[i, j-1] -
                                4 * self.smoke[i, j])
                    new_smoke[i, j] += 0.1 * laplacian
        
        # Wind moves smoke
        shift_x = int(self.wind_x * 10)
        shift_y = int(self.wind_y * 10)
        shifted = np.roll(self.smoke, shift_x, axis=1)
        shifted = np.roll(shifted, shift_y, axis=0)
        new_smoke = 0.7 * new_smoke + 0.3 * shifted
        
        # Walls block smoke
        new_smoke[self.wall == 1] = 0
        
        # Smoke fades
        new_smoke *= 0.99
        self.smoke = np.maximum(new_smoke, 0)
        
# Setup
print("\nCreating simulation...")
sim = SmokeSimulator()

# Create figure
fig, ax = plt.subplots(1, 1, figsize=(8, 8))
plt.subplots_adjust(bottom=0.15)

# Display
img = ax.imshow(sim.smoke, cmap='hot', vmin=0, vmax=2, interpolation='bilinear')
plt.colorbar(img, ax=ax, label='Smoke Concentration')
ax.set_title('Smoke Physics Simulation\n(Click to add smoke, wind changes automatically)')

# Instructions text
instruction_text = ax.text(2, 60, '💨 Click anywhere to add smoke', 
                           color='white', fontsize=10, 
                           bbox=dict(boxstyle="round,pad=0.3", facecolor='black', alpha=0.7))

# Wind display
wind_display = ax.text(2, 5, '', color='cyan', fontsize=11, 
                       bbox=dict(boxstyle="round,pad=0.3", facecolor='black', alpha=0.7))

# Wind animation counter
wind_step = 0

def update(frame):
    global wind_step
    
    # Change wind direction every 150 frames
    wind_step += 1
    if wind_step < 150:
        sim.wind_x = 0.2
        sim.wind_y = 0.0
        wind_dir = "→ Moving RIGHT"
    elif wind_step < 300:
        sim.wind_x = -0.2
        sim.wind_y = 0.0
        wind_dir = "← Moving LEFT"
    elif wind_step < 450:
        sim.wind_x = 0.0
        sim.wind_y = 0.2
        wind_dir = "↑ Moving UP"
    else:
        wind_step = 0
        wind_dir = "↗ Moving DIAGONAL"
        sim.wind_x = 0.15
        sim.wind_y = 0.15
    
    # Update display
    wind_display.set_text(f'Wind: ({sim.wind_x:.2f}, {sim.wind_y:.2f}) {wind_dir}')
    
    # Step simulation
    sim.step()
    img.set_array(sim.smoke)
    
    return [img, wind_display]

def onclick(event):
    if event.inaxes == ax:
        x, y = int(event.xdata), int(event.ydata)
        if 0 <= x < 64 and 0 <= y < 64:
            sim.add_smoke(x, y, 4.0)
            print(f"💨 Added smoke at ({x}, {y})")

# Connect click event
fig.canvas.mpl_connect('button_press_event', onclick)

print("\n" + "="*50)
print("✅ DEMO READY!")
print("="*50)
print("🎮 HOW TO USE:")
print("   1. Click anywhere on the smoke visualization")
print("   2. Watch how smoke spreads and moves")
print("   3. Wind direction changes automatically every few seconds")
print("   4. Close the window to exit")
print("="*50 + "\n")

print("Starting animation window...")
print("(If window doesn't appear, check your matplotlib backend)")
print()

# Run animation
ani = FuncAnimation(fig, update, interval=50, cache_frame_data=False)
plt.show()

print("\n✅ Demo closed")